insert into StatusApartamento(idStatusApartamento, descricao) values(1,'Liberado');
insert into StatusApartamento(idStatusApartamento, descricao) values(2,'Ocupado');


insert into Apartamento values(1,'Quarto 101', 101, 1);
insert into Apartamento values(2,'Quarto 102', 102, 2);
insert into Apartamento values(3,'Quarto 103', 103, 1);
insert into Apartamento values(4,'Quarto 104', 104, 2);
insert into Apartamento values(5,'Quarto 105', 105, 1);


insert into Pessoa values(1,'Gabriel Petrovick', 'petrovickg@hotmail.com');
insert into Pessoa values(2,'Luis Anderson', 'anderson@hotmail.com');
insert into Pessoa values(3,'Unipam', 'unipam@hotmail.com');
insert into Pessoa values(4,'Luis Campos', 'campos@hotmail.com');


insert into PessoaFisica values(1, '10180179683');
insert into PessoaFisica values(2, '99988877721');
insert into PessoaFisica values(4, '99889978987');


insert into PessoaFisica values(3, '12345678901234567890');

insert into Cliente values(1);
insert into Cliente values(2);
insert into Cliente values(3);
insert into Cliente values(4);


