package br.com.projetowebii.entidade;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PessoaJuridica")
public class PessoaJuridica implements Serializable
{
    @Id
    @Column(name = "IdPessoa", nullable = false, updatable = false, insertable = false)
    private Integer idPessoa;
    
    @Column(name = "Cnpj", nullable = false)
    private String cnpj;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdPessoa", nullable = false)
    private Pessoa pessoa;

    public Integer getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(Integer idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }
    

}
