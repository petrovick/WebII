package br.com.projetowebii.serviceimple;

import br.com.projetowebii.entidade.StatusApartamento;
import br.com.projetowebii.service.IStatusApartamentoService;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author petrovick
 */
@Stateless
public class StatusApartamentoService implements IStatusApartamentoService
{
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<StatusApartamento> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String remover(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String salvar(StatusApartamento obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
