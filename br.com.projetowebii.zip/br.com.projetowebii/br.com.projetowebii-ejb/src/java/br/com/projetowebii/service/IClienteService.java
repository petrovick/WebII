package br.com.projetowebii.service;

import br.com.projetowebii.entidade.Cliente;
import br.com.projetowebii.entidade.Pessoa;
import java.util.List;

/**
 *
 * @author petrovick
 */
public interface IClienteService extends ICrudGenerico<Cliente>
{
;
    public List<Cliente> listarNome(String str);

    public Cliente obter(Integer idPessoa);
    
    public List<Cliente> listarClienteParaAutoComplete(String query);
    
}
