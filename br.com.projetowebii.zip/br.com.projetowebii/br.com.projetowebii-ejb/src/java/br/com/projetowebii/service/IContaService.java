package br.com.projetowebii.service;

import br.com.projetowebii.entidade.Conta;
import java.util.List;

/**
 *
 * @author petrovick
 */
public interface IContaService extends ICrudGenerico<Conta>
{
    public List<Conta> listar();
    public String remover(Integer id);
    public String salvar(Conta obj);
    public Conta obter(Integer idConta);
    
}
