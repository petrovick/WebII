package br.com.projetowebii.service;

import br.com.projetowebii.entidade.Cliente;
import br.com.projetowebii.entidade.PessoaFisica;
import br.com.projetowebii.entidade.PessoaJuridica;
import java.util.List;

/**
 *
 * @author petrovick
 */
public interface IPessoaJuridicaService extends ICrudGenerico<PessoaJuridica>
{
    public List<PessoaJuridica> listar();
    public List<PessoaJuridica> listarNome(String str);
    public String remover(Integer id);
    public String salvar(PessoaJuridica obj);
    
}