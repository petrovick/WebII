package br.com.projetowebii.service;

import br.com.projetowebii.entidade.Apartamento;
import br.com.projetowebii.entidade.Reserva;
import java.util.List;

/**
 *
 * @author petrovick
 */
public interface IReservaService extends ICrudGenerico<Reserva>
{
    public List<Reserva> listar();
    public String remover(Integer id);
    public String salvar(Reserva obj);
    public List<Apartamento> listarApartamento();
}
