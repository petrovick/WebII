package br.com.projetowebii.serviceimple;

import br.com.projetowebii.entidade.StatusReserva;
import br.com.projetowebii.service.IStatusReservaService;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author petrovick
 */
@Stateless
public class StatusReservaService implements IStatusReservaService
{
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<StatusReserva> listar()
    {
        TypedQuery<StatusReserva> statusReservaQuery = em.createQuery("select sr from StatusReserva as sr", StatusReserva.class);
        return statusReservaQuery.getResultList();
    }   

    @Override
    public String remover(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String salvar(StatusReserva obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public StatusReserva obter(String descStatusReserva)
    {
        //Criar TypedQuery para pegar o objeto StatusReserva de acordo com a descricao
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
