package br.com.projetowebii.teste;

import br.com.projetowebii.entidade.Apartamento;
import br.com.projetowebii.entidade.Cliente;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import br.com.projetowebii.entidade.Pessoa;
import br.com.projetowebii.entidade.Reserva;
import br.com.projetowebii.entidade.StatusReserva;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

public class Main
{
    static EntityManager em = Persistence.createEntityManagerFactory("br.com.projetowebii-ejbPU").createEntityManager();
    public static void main(String[] args)
    {
/*        em.getTransaction().begin();
        TypedQuery<Pessoa> pessoaQuery = em.createQuery("select p from Pessoa p", Pessoa.class);
        List<Pessoa> listaPessoa = pessoaQuery.getResultList();
        for(Pessoa pp : listaPessoa)
            System.out.println("" + pp.getNome());
*/
/*        em.getTransaction().begin();
        TypedQuery<Apartamento> pessoaQuery = em.createQuery("select p from Apartamento p", Apartamento.class);
        List<Apartamento> listaPessoa = pessoaQuery.getResultList();
        for(Apartamento pp : listaPessoa)
            System.out.println("" + pp.getIdApartamento());
        
*/
        
        
/*
        Pessoa p = new Pessoa();
        p.setNome("Muahhaha");
        p.setEmail("emailMuhaahha");
        
        em.persist(p);
        em.getTransaction().commit();
*/
        
        Date d = new Date();
        DateFormat df = DateFormat.getDateInstance();
        
        short s = 2;
        Reserva r = new Reserva();
        r.setCliente(em.find(Cliente.class, 1));
        r.setDataRealizacaoReserva(new Date(df.format(d)));
        r.setDataReserva(new Date(df.format(d)));
        r.setDuracaoReserva(s);
        r.setStatusReserva(em.find(StatusReserva.class, 1));
        em.getTransaction().begin();
        
        if(r.getIdReserva() != null)
            em.merge(r);
        else
            em.persist(r);

        
    }
    
}
