package br.com.projetowebii.entidade;

import java.math.BigDecimal;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotNull;

@Entity
public class Conta
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdConta", nullable = false)
    private Integer idConta;
    
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "conta")
    private List<Pagamento> pagamentos;
   
    @Column(name = "Descricao", nullable = false)
    @NotNull
    private String descricao;
    
    @Column(name = "ValorConta", nullable = false)
    private BigDecimal valorConta;
    
    @JoinColumn(name = "IdPessoa", referencedColumnName = "IdPessoa")
    @ManyToOne(optional = false)
    private Cliente idPessoa;

    public Cliente getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(Cliente idPessoa) {
        this.idPessoa = idPessoa;
    }
    
    public Integer getIdConta() {
        return idConta;
    }

    public void setIdConta(Integer idConta) {
        this.idConta = idConta;
    }

    public List<Pagamento> getPagamentos() {
        return pagamentos;
    }

    public void setPagamentos(List<Pagamento> pagamentos) {
        this.pagamentos = pagamentos;
    }
    
    public BigDecimal getValorConta() {
        return valorConta;
    }

    public void setValorConta(BigDecimal valorConta) {
        this.valorConta = valorConta;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}