package br.com.projetowebii.entidade;

import java.util.List;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Escala
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer IdEscala;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdPessoa", nullable = false)
    private Funcionario funcionario;

    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdHorarioInicio")
    private Horario horarioInicio;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdHorarioFim")
    private Horario horarioFim;
    
    
    public Integer getIdEscala() {
        return IdEscala;
    }

    public void setIdEscala(Integer IdEscala) {
        this.IdEscala = IdEscala;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public Horario getHorarioInicio() {
        return horarioInicio;
    }

    public void setHorarioInicio(Horario horarioInicio) {
        this.horarioInicio = horarioInicio;
    }

    public Horario getHorarioFim() {
        return horarioFim;
    }

    public void setHorarioFim(Horario horarioFim) {
        this.horarioFim = horarioFim;
    }
}