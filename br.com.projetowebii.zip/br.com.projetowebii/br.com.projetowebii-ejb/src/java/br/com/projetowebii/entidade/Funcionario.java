package br.com.projetowebii.entidade;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Funcionario")
public class Funcionario
{
    
    @Id
    @Column(name = "IdPessoa", nullable = false,updatable = false, insertable = false)
    private Integer idPessoa;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdPessoa", nullable = false)
    private Pessoa pessoa;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdPapel", nullable = false)
    private Papel papel;
    
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "funcionario")
    private List<Escala> escala;
    

    public Papel getPapel() {
        return papel;
    }

    public void setPapel(Papel papel) {
        this.papel = papel;
    }

    public List<Escala> getEscala() {
        return escala;
    }

    public void setEscala(List<Escala> escala) {
        this.escala = escala;
    }
}