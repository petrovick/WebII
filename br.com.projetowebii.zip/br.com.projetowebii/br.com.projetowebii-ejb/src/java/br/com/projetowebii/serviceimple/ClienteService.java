package br.com.projetowebii.serviceimple;


import br.com.projetowebii.entidade.*;
import br.com.projetowebii.service.IClienteService;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author petrovick
 */
@Stateless
public class ClienteService implements IClienteService
{
    @PersistenceContext
    private EntityManager em;
    
    @Override
    public List<Cliente> listar() {
        TypedQuery<Cliente> clienteQuery = em.createQuery("select c from Cliente as c", Cliente.class);
        return clienteQuery.getResultList();
    }

    @Override
    public List<Cliente> listarNome(String nome)
    {
        nome = nome == null ? "" : nome;
        TypedQuery<Cliente> clienteQuery = em.createQuery("select a from Cliente as a INNER JOIN FETCH a.pessoa as p where p.nome like :nome ORDER BY p.nome", Cliente.class);
        clienteQuery.setParameter("nome", "%"+ nome +"%");
        return clienteQuery.getResultList();
    }

    @Override
    public String remover(Integer idCliente)
    {
        try
        {
            Cliente cliente = obter(idCliente);
            em.remove(cliente);
        }
        catch(Exception ex)
        {
            return ex.getMessage();
        }
        return null;
    }

    @Override
    public String salvar(Cliente cliente)
    {
        try
        {
            System.out.println("OUTRO ID:" + cliente.getIdPessoa());
            
            if(cliente.getPessoa().getPessoaFisica() != null)
            {
                salvaPf(cliente);
            }
            else if(cliente.getPessoa().getPessoaJuridica() != null)
            {
                salvaPj(cliente);
            }
        }
        catch(Exception ex)
        {
            return ex.getMessage();
        }
        return null;
    }
    
    public String salvaPf(Cliente cliente)
    {
        try
        {
            cliente.getPessoa().getPessoaFisica().setPessoa(cliente.getPessoa());
            cliente.getPessoa().setCliente(cliente);
            
            System.out.println("PessoaFisica OUTRO ID:" + cliente.getIdPessoa());
            
            if(cliente.getPessoa().getIdPessoa() != null)
            {
                System.out.println("PessoaFisica Merge");
                em.merge(cliente.getPessoa());
                
            }
            else
            {
                System.out.println("PessoaFisica Persiste");
                em.persist(cliente);
            }
        }
        catch(Exception ex)
        {
            return ex.getMessage();
        }
        return null;
    }
    
    public String salvaPj(Cliente cliente)
    {
        try
        {
            
            
            cliente.getPessoa().setCliente(cliente);
            cliente.getPessoa().setPessoaJuridica(cliente.getPessoa().getPessoaJuridica());
            
            System.out.println("PessoaJuridica OUTRO ID:" + cliente.getIdPessoa());
            
            if(cliente.getIdPessoa() != null)
            {
                System.out.println("PessoaFisica Merge");
                em.merge(cliente);
            }
            else
            {
                System.out.println("PessoaFisica Persist");
                em.persist(cliente);
            }
        }
        catch(Exception ex)
        {
            return ex.getMessage();
        }
        return null;
    }

    @Override
    public Cliente obter(Integer idCliente)
    {
        Cliente cliente = em.find(Cliente.class, idCliente);
        return cliente;
    }

    @Override
    public List<Cliente> listarClienteParaAutoComplete(String query) {
        TypedQuery<Cliente> clienteQuery = em.createQuery("select c from Cliente as c where c.pessoa.nome like :nome",Cliente.class);
        clienteQuery.setParameter("nome", query + "%");
        return clienteQuery.getResultList();
    }
}
