package br.com.projetowebii.service;

import br.com.projetowebii.entidade.Apartamento;
import java.util.List;

/**
 *
 * @author petrovick
 */
public interface IApartamentoService extends ICrudGenerico<Apartamento>
{
    public List<Apartamento> listar();
    public String remover(Integer id);
    public String salvar(Apartamento obj);
    public Apartamento obter(Integer idApartamento);
    public List<Apartamento> listarClienteParaAutoComplete(String pesquisaQuarto);
}