package br.com.projetowebii.teste;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author petrovick
 */
@Entity
@Table(name = "Venda")
public class Venda
{
    @Id
    private Integer Venda;

    public Integer getVenda() {
        return Venda;
    }

    public void setVenda(Integer Venda) {
        this.Venda = Venda;
    }
    
    
    
    
}
