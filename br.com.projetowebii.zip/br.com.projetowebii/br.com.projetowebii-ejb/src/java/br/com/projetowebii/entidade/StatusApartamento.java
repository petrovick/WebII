package br.com.projetowebii.entidade;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "StatusApartamento")
public class StatusApartamento implements Serializable
{
    @Id
    @Column(name = "IdStatusApartamento", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Short idStatusApartamento;
    
    @Column(name = "Descricao", nullable = false, length = 50)
    private String descricao;
    
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "statusApartamento")
    List<Apartamento> apartamentos;

    public Short getIdStatusApartamento() {
        return idStatusApartamento;
    }

    public void setIdStatusApartamento(Short idStatusApartamento) {
        this.idStatusApartamento = idStatusApartamento;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public List<Apartamento> getApartamentos() {
        return apartamentos;
    }

    public void setApartamentos(List<Apartamento> apartamentos) {
        this.apartamentos = apartamentos;
    }
    
    
    
}
