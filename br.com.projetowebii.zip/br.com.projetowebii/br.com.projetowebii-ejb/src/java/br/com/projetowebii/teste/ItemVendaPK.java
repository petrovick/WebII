/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.projetowebii.teste;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Embedded;

/**
 *
 * @author petrovick
 */

@Embeddable
public class ItemVendaPK
{
    @Column(name = "idItem")
    private Integer idItem;
    
    @Column(name = "idVenda")
    private Integer idVenda;
    
    
}
