package br.com.projetowebii.entidade;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class StatusReserva implements Serializable
{
    @Id
    @Column(name = "IdStatusReserva")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Short idStatusReserva;
    
    @Column(name = "Descricao", nullable = false)
    private String descricao;
    
    @OneToMany(mappedBy = "statusReserva", fetch = FetchType.LAZY)
    private List<Reserva> reserva;

    public Short getIdStatusReserva() {
        return idStatusReserva;
    }

    public void setIdStatusReserva(Short idStatusReserva) {
        this.idStatusReserva = idStatusReserva;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public List<Reserva> getReserva() {
        return reserva;
    }

    public void setReserva(List<Reserva> reserva) {
        this.reserva = reserva;
    }
    
    
    
}
