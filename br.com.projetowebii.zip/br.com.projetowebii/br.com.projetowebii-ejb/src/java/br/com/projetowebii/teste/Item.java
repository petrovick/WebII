package br.com.projetowebii.teste;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author petrovick
 */
@Entity
@Table(name = "Item")
public class Item {
    @Id
    private Integer idItem;

    public Integer getIdItem() {
        return idItem;
    }

    public void setIdItem(Integer idItem) {
        this.idItem = idItem;
    }
    
}
