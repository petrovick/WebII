package br.com.projetowebii.service;

import br.com.projetowebii.entidade.Pagamento;

/**
 *
 * @author Petrovick
 */
public interface IPagamentoService extends ICrudGenerico<Pagamento>
{
    
    
}
