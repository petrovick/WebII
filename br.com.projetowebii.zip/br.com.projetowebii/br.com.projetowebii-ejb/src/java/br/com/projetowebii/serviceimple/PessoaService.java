
package br.com.projetowebii.serviceimple;

import br.com.projetowebii.service.IPessoaService;
import br.com.projetowebii.entidade.Pessoa;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;


@Stateless //Cria um EJB de seção do tipo nao armazenar o estado do objeto
public class PessoaService implements IPessoaService{

    @PersistenceContext //cria ainstancia e controla as transações
    private EntityManager em;
    
    @Override
    public List<Pessoa> listar()
    {
        TypedQuery<Pessoa> pessoaQuery = em.createQuery("select p from Pessoa as p", Pessoa.class);
        return pessoaQuery.getResultList();
    }
    
    @Override
    public String remover(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String salvar(Pessoa obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
