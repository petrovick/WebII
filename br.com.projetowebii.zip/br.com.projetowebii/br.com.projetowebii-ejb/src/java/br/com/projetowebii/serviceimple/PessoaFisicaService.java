package br.com.projetowebii.serviceimple;

import br.com.projetowebii.entidade.PessoaFisica;
import br.com.projetowebii.service.IPessoaFisicaService;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author petrovick
 */
@Stateless
public class PessoaFisicaService implements IPessoaFisicaService
{
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<PessoaFisica> listar() {
        TypedQuery<PessoaFisica> pessoaFisicaQuery = em.createQuery("select pf from PessoaFisica as pf", PessoaFisica.class);
        return pessoaFisicaQuery.getResultList();
    }

    @Override
    public List<PessoaFisica> listarNome(String str) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String remover(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String salvar(PessoaFisica obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
