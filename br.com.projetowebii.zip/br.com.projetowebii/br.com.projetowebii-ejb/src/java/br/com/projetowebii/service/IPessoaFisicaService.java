package br.com.projetowebii.service;

import br.com.projetowebii.entidade.Cliente;
import br.com.projetowebii.entidade.PessoaFisica;
import java.util.List;

/**
 *
 * @author petrovick
 */
public interface IPessoaFisicaService extends ICrudGenerico<PessoaFisica>
{
    public List<PessoaFisica> listar();
    public List<PessoaFisica> listarNome(String str);
    public String remover(Integer id);
    public String salvar(PessoaFisica obj);
}
