package br.com.projetowebii.entidade;

import java.sql.Time;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Horario
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "IdHorario", nullable = false)
    private Short idHorario;
    
    @Column(name = "Horario", nullable = false)
    private Time horario;
    
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "horarioInicio")
    private List<Escala> escalaInicio;
    
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "horarioFim")
    private List<Escala> escalaFim;
    
    
    
    
    
    public Short getIdHorario() {
        return idHorario;
    }

    public void setIdHorario(Short idHorario) {
        this.idHorario = idHorario;
    }

    public Time getHorario() {
        return horario;
    }

    public void setHorario(Time horario) {
        this.horario = horario;
    }

    public List<Escala> getEscalaInicio() {
        return escalaInicio;
    }

    public void setEscalaInicio(List<Escala> escalaInicio) {
        this.escalaInicio = escalaInicio;
    }

    public List<Escala> getEscalaFim() {
        return escalaFim;
    }

    public void setEscalaFim(List<Escala> escalaFim) {
        this.escalaFim = escalaFim;
    }
    
}