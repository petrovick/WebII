package br.com.projetowebii.entidade;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Apartamento")
public class Apartamento implements Serializable
{
    @Id
    @Column(name = "IdApartamento", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idApartamento;
    
    @Column(name = "Descricao", nullable = false)
    private String descricao;
    
    @Column(name = "NumeroQuartos", nullable = false)
    private Integer numeroQuartos;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdStatusApartamento", nullable = false)
    private StatusApartamento statusApartamento;
/*    
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "apartamento")
    private Reserva reserva;
*/
    public Integer getIdApartamento() {
        return idApartamento;
    }
    
    public void setIdApartamento(Integer idApartamento) {
        this.idApartamento = idApartamento;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Integer getNumeroQuartos() {
        return numeroQuartos;
    }

    public void setNumeroQuartos(Integer numeroQuartos) {
        this.numeroQuartos = numeroQuartos;
    }

    public StatusApartamento getStatusApartamento() {
        return statusApartamento;
    }

    public void setStatusApartamento(StatusApartamento statusApartamento) {
        this.statusApartamento = statusApartamento;
    }
/*
    public Reserva getReserva() {
        return reserva;
    }

    public void setReserva(Reserva reserva) {
        this.reserva = reserva;
    }
*/    
}
