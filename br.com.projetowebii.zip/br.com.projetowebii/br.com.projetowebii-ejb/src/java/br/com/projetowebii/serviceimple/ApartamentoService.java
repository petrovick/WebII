package br.com.projetowebii.serviceimple;

import br.com.projetowebii.entidade.Apartamento;
import br.com.projetowebii.service.IApartamentoService;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
/**
 *
 * @author petrovick
 */
@Stateless
public class ApartamentoService implements IApartamentoService 
{
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<Apartamento> listar()
    {
        TypedQuery<Apartamento> apartamentoQuery = em.createQuery("select a from Apartamento as a", Apartamento.class);
        return apartamentoQuery.getResultList();
    }
    
    
    @Override
    public Apartamento obter(Integer idApartamento)
    {
        Apartamento apartamento = em.find(Apartamento.class, idApartamento);
        return apartamento;
    }
    
    
    @Override
    public String remover(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String salvar(Apartamento obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    public List<Apartamento> listarClienteParaAutoComplete(String pesquisaQuarto)
    {
        TypedQuery<Apartamento> apartamentoQuery = em.createQuery("select a from Apartamento as a where a.descricao like :quarto",Apartamento.class);
        apartamentoQuery.setParameter("quarto", pesquisaQuarto + "%");
        return apartamentoQuery.getResultList();
    }
    
    
    
}
