package br.com.projetowebii.entidade;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Reserva implements Serializable
{
    @Id
    @Column(name = "IdReserva", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idReserva;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "DataRealizacaoReserva", nullable = false)
    private Date dataRealizacaoReserva;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "DataReserva", nullable = false)
    private Date dataReserva;
    
    @Column(name = "DuracaoReserva", nullable = false)
    private Short duracaoReserva;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdPessoa", nullable = false)
    private Cliente cliente;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdStatusReserva", nullable = false)
    private StatusReserva statusReserva;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdConta", nullable = false)
    private Conta conta; 
    
//    @ManyToOne(fetch = FetchType.LAZY)
 //   @JoinColumn(name = "IdApartamento", nullable = false)
//    private Apartamento apartamento;

    public Integer getIdReserva() {
        return idReserva;
    }

    public void setIdReserva(Integer idReserva) {
        this.idReserva = idReserva;
    }

    public Date getDataRealizacaoReserva() {
        return dataRealizacaoReserva;
    }

    public void setDataRealizacaoReserva(Date dataRealizacaoReserva) {
        this.dataRealizacaoReserva = dataRealizacaoReserva;
    }

    public Date getDataReserva() {
        return dataReserva;
    }

    public void setDataReserva(Date dataReserva) {
        this.dataReserva = dataReserva;
    }

    public Short getDuracaoReserva() {
        return duracaoReserva;
    }

    public void setDuracaoReserva(Short duracaoReserva) {
        this.duracaoReserva = duracaoReserva;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public StatusReserva getStatusReserva() {
        return statusReserva;
    }

    public void setStatusReserva(StatusReserva statusReserva) {
        this.statusReserva = statusReserva;
    }

    public Conta getConta() {
        return conta;
    }

    public void setConta(Conta conta) {
        this.conta = conta;
    }
/*
    public Apartamento getApartamento() {
        return apartamento;
    }

    public void setApartamento(Apartamento apartamento) {
        this.apartamento = apartamento;
    }
*/    
    
}
