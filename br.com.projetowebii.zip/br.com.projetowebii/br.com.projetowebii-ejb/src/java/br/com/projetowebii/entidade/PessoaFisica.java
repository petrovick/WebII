package br.com.projetowebii.entidade;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "PessoaFisica")
public class PessoaFisica implements Serializable
{
    @Id
    @Column(name = "IdPessoa", nullable = false, updatable = false, insertable = false)
    private Integer idPessoa;
    
    @Column(name = "Cpf", nullable = false)
    private String cpf;
    
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "IdPessoa", nullable = false)
    private Pessoa pessoa;

    public Integer getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(Integer idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }
    
    
}
