package br.com.projetowebii.serviceimple;

import br.com.projetowebii.entidade.Reserva;
import br.com.projetowebii.entidade.Apartamento;
import br.com.projetowebii.service.IReservaService;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 * @author petrovick
 */
@Stateless
public class ReservaService implements IReservaService
{
    @PersistenceContext
    private EntityManager em = Persistence.createEntityManagerFactory("br.com.projetowebii-ejbPU").createEntityManager();;

    @Override
    public List<Reserva> listar()
    {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    @Override
    public List<Apartamento> listarApartamento()
    {
        TypedQuery<Apartamento> apartamentoQuery = em.createQuery("select a from Apartamento a", Apartamento.class);
        return apartamentoQuery.getResultList();
    }

    @Override
    public String remover(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String salvar(Reserva obj)
    { 
        try
        {
            if(obj.getIdReserva() != null)
                em.merge(obj);
            else
                em.persist(obj);
        }
        catch(Exception ex)
        {
            return ex.getMessage();
        }
        return null;
    }
}
