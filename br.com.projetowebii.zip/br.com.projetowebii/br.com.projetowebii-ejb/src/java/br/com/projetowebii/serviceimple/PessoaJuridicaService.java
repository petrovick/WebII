package br.com.projetowebii.serviceimple;

import br.com.projetowebii.entidade.PessoaJuridica;
import br.com.projetowebii.service.IPessoaJuridicaService;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 *
 * @author petrovick
 */
@Stateless
public class PessoaJuridicaService implements IPessoaJuridicaService
{
    @PersistenceContext
    private EntityManager em;
    
    @Override
    public List<PessoaJuridica> listar()
    {
        TypedQuery<PessoaJuridica> pessoaJuridicaService = em.createQuery("select pj from PessoaJuridica as pj", PessoaJuridica.class);
        return pessoaJuridicaService.getResultList();
    }

    @Override
    public List<PessoaJuridica> listarNome(String str) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String remover(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String salvar(PessoaJuridica obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
