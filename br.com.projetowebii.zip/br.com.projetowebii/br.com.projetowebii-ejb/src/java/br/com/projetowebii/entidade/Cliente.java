package br.com.projetowebii.entidade;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Cliente")
public class Cliente implements Serializable
{
    @Id
    @Column(name = "IdPessoa", insertable = false, updatable = false)
    private Integer idPessoa;
    
    @JoinColumn(name = "IdPessoa", referencedColumnName = "IdPessoa")
    @OneToOne(optional = false, fetch = FetchType.LAZY)
    private Pessoa pessoa;
    
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idPessoa")
    private Collection<Conta> contas;

    public Collection<Conta> getContaCollection() {
        return contas;
    }

    public void setContaCollection(Collection<Conta> contaCollection) {
        this.contas = contaCollection;
    }
    
    public Integer getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(Integer idPessoa) {
        this.idPessoa = idPessoa;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }
    
    
    
}
