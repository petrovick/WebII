package br.com.projetowebii.service;

import java.util.List;

/**
 *
 * @author petrovick
 */
public interface ICrudGenerico<T>
{
    public List<T> listar();
    public String remover(Integer id);
    public String salvar(T obj);
}
