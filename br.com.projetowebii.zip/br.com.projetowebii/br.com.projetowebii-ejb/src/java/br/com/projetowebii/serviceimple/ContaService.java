package br.com.projetowebii.serviceimple;

import br.com.projetowebii.entidade.Conta;
import br.com.projetowebii.service.IContaService;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author petrovick
 */
@Stateless
public class ContaService implements IContaService
{
    @PersistenceContext
    private EntityManager em;

    @Override
    public List<Conta> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String remover(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String salvar(Conta obj) {
        try
        {
            if(obj.getIdConta() != null)
                em.merge(obj);
            else
                em.persist(obj);
        }catch(Exception ex)
        {
            return ex.getMessage();
        }
        return null;
    }

    @Override
    public Conta obter(Integer idConta) {
        return em.find(Conta.class, idConta);
    }
    
    
    
}
