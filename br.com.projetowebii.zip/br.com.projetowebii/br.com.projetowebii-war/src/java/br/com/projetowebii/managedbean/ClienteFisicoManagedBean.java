package br.com.projetowebii.managedbean;

import br.com.projetowebii.service.IClienteService;
import javax.ejb.EJB;
import javax.faces.bean.ViewScoped;
import javax.inject.Named;
import br.com.projetowebii.entidade.Cliente;
import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import br.com.projetowebii.entidade.Pessoa;
import br.com.projetowebii.entidade.PessoaFisica;
import br.com.projetowebii.util.MensagemUtil;


/**
 *
 * @author root
 */
@Named(value = "clienteFisicoManagedBean")
@ViewScoped
public class ClienteFisicoManagedBean
{
    @EJB
    private IClienteService clienteService;
    private Cliente cliente;
    
    @PostConstruct
    public void init()
    {
        cliente = new Cliente();
        cliente.setPessoa(new Pessoa());
        cliente.getPessoa().setPessoaFisica(new PessoaFisica());
    }
    
    public void salvar()
    {
        String erro = clienteService.salvar(cliente);
        if(erro == null)
            MensagemUtil.addMensgeamInfo("Cliente salvo com sucesso");
        else
            MensagemUtil.addMensgeamInfo("Cliente não foi salvo.\n\n" + erro);
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    
    
}
