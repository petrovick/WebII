package br.com.projetowebii.managedbean;

import br.com.projetowebii.entidade.Apartamento;
import br.com.projetowebii.entidade.Cliente;
import br.com.projetowebii.entidade.Conta;
import br.com.projetowebii.entidade.Reserva;
import br.com.projetowebii.service.IApartamentoService;
import br.com.projetowebii.service.IClienteService;
import br.com.projetowebii.service.IReservaService;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;
import br.com.projetowebii.entidade.StatusReserva;
import br.com.projetowebii.service.IStatusReservaService;
import br.com.projetowebii.serviceimple.ContaService;
import java.math.BigDecimal;

@Named(value = "realizarReservaManagedBean")
@RequestScoped
public class realizarReservaManagedbean
{
    @EJB
    private IReservaService reservaService;
    @EJB
    private IApartamentoService apartamentoService;
    @EJB
    private IClienteService clienteService;
    @EJB
    private IStatusReservaService statusReservaService;
    
    private Integer apartamentoDePesquisaParaAutoComplete;
    private Date dataReserva;
    private Short numeroDias;
    private Integer clienteDePesquisaParaAutoComplete;
    private BigDecimal valorConta;
    private Reserva reserva;
    
    
    
    
    public List<Cliente> listarClienteParaAutoComplete(String queryDePesquisaParaAutoComplete)
    {
        List<Cliente> aa = clienteService.listarClienteParaAutoComplete(queryDePesquisaParaAutoComplete);
        System.out.println("AA: " + aa);
        for(Cliente c : aa)
        {
            System.out.println("AAAAA:" + c.getIdPessoa());
        }
        return aa;
        
    }
    
    public void setApartamentoDePesquisaParaAutoComplete(Integer apartamentoDePesquisaParaAutoComplete)
    {
        this.apartamentoDePesquisaParaAutoComplete = apartamentoDePesquisaParaAutoComplete;
    }
    
    public Integer getApartamentoDePesquisaParaAutoComplete()
    {
        return apartamentoDePesquisaParaAutoComplete;
    }
    
    public List<Apartamento> listarApartamentoParaAutoComplete(String quarto)
    {
        List<Apartamento> aa = apartamentoService.listarClienteParaAutoComplete(quarto);
        for(Apartamento a : aa)
        {
            System.out.println("AAAA:" + a.getDescricao());
        }
        return aa;
    }
    
    public void setDataReserva(Date dataReserva)
    {
        this.dataReserva = dataReserva;
    }
    
    public Date getDataReserva()
    {
        return this.dataReserva;
    }
    
    public void setNumeroDias(Short numeroDias)
    {
        this.numeroDias = numeroDias;
    }
    
    
    public Short getNumeroDias()
    {
        return numeroDias;
    }
    
    
    public void salvar()
    {
        Date d = new Date();
        DateFormat df = DateFormat.getDateInstance();
        /*
        //Dependencias - Conta
        Conta conta = new Conta();
        conta.setDescricao("Alguel");
        conta.setIdPessoa(clienteService.obter(clienteDePesquisaParaAutoComplete));
        conta.setValorConta(valorConta);
        new ContaService().salvar(conta);
        */
        reserva.setCliente(clienteService.obter(clienteDePesquisaParaAutoComplete));
 //       reserva.setApartamento(apartamentoService.obter(apartamentoDePesquisaParaAutoComplete));
        reserva.setDataRealizacaoReserva(new Date(df.format(d)));
        
        reservaService.salvar(reserva);
        
    }

    public Integer getClienteDePesquisaParaAutoComplete() {
        return clienteDePesquisaParaAutoComplete;
    }

    public void setClienteDePesquisaParaAutoComplete(Integer clienteDePesquisaParaAutoComplete) {
        this.clienteDePesquisaParaAutoComplete = clienteDePesquisaParaAutoComplete;
    }

    public BigDecimal getValorConta() {
        return valorConta;
    }

    public void setValorConta(BigDecimal valorConta) {
        this.valorConta = valorConta;
    }

    public Reserva getReserva() {
        return reserva;
    }

    public void setReserva(Reserva reserva) {
        this.reserva = reserva;
    }
    
    
}
